package com.service.findservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FindserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
